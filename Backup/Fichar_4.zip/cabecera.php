<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="estilo.css" rel="stylesheet" type="text/css"> 
        <title><?= $titulo ?></title>
    </head>
    <body>
        <div class = "navbar">
            <form method="post">
                <button type = submit name = dashboard>Inicio</button>
                <button type = submit name = crear>Crear usuario</button>
                <button type = submit name = users>Usuarios</button>
                <button type = submit name = editame>Mis datos</button>
                <button type = submit name = logout>Salir</button>
            </form>
        </div>
