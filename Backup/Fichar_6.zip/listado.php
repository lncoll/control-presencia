<?php
$titulo = "Listado de usuarios";
include 'cabecera.php';
$inicio = '2024-12-01';
$fin = '2024-12-31';

$stmt = $conn->stmt_init();
$stmt->prepare("SELECT reg_time, entrada FROM registros WHERE reg_time BETWEEN ? AND ? AND user_id = ? ORDER BY reg_id ASC;");
try {
    $stmt->bind_param("ssi", $inicio, $fin, $_SESSION['user_id']);
    $stmt->execute();
    $stmt->store_result();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>
        <table id="customers">
            <caption>Registros del mes de: --- Para: ---</caption>
            <tr><th>Fecha:</th><th>Entrada:</th><th>Salida:</th><th>Tiempo:</th></tr>
<?php
            if ($stmt->num_rows > 0) {
                $stmt->bind_result($reg_time, $entrada);
                while($row = $stmt->fetch()) {
                    if ($entrada) {
                        $ent = new DateTime($reg_time);
                        $fecha = $ent->format('d/m/Y');
                        if ($sal) {
                            $lapso = $ent->diff($sal);
                            echo "<tr><td>" . $fecha . "</td><td>" . $ent->format('H:i') . "</td><td>" . $sal->format('H:i') . "</td><td>" . $lapso->format('%H:%I') . "</td></tr>\n";
                        } else
                            echo "<tr><td>" . $fecha . "</td><td>" . $ent->format('H:i') . "</td><td>---</td><td>---</td></tr>\n";                        
                    } else {
                        $sal = new DateTime($reg_time);
                    }
                }
            } else {
                echo "<tr><td colspan='4'>No hay registros</td></tr>";
            }
            $stmt->close();
            ?>
        </table>
    </body>
</html>