<?php
include_once 'global.php';

if (!isset($_SESSION['user_id']) && !isset($_POST['login'])) {
    include "login.php";
    exit();
}

function login($username, $password) {
    global $conn;
    try {
        $stmt = $conn->stmt_init();
        $stmt->prepare("SELECT * FROM empleados WHERE username = ? AND password = PASSWORD(?) AND role > 0");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($user_id, $username, $nombre, $password, $NIF, $email, $dentro, $role);
        if ($stmt->num_rows > 0) {
            $stmt->fetch();
            $_SESSION['user_id'] = $user_id;
            $_SESSION['role'] = $role;
            $_SESSION['NIF'] = $NIF;
            $_SESSION['email'] = $email;
            $_SESSION['username'] = $username;
            $_SESSION['nombre'] = $nombre;
            $_SESSION['dentro'] = $dentro;
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function registerEntry($user_id) {
    global $conn;
    if ($_SESSION['dentro']) {
        include "dashboard.php";
        exit();
    }
    try {
        $stmt = $conn->stmt_init();
        $stmt->prepare("INSERT INTO registros (user_id, reg_time, entrada, creado) VALUES (?, NOW(), TRUE, NOW())");
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $stmt = $conn->prepare("UPDATE empleados SET dentro = 1 WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $_SESSION['dentro'] = true;
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function registerExit($user_id) {
    global $conn;
    if (!$_SESSION['dentro']) {
        include "dashboard.php";
        exit();
    }
    try {
        $stmt = $conn->stmt_init();
        $stmt->prepare("INSERT INTO registros (user_id, reg_time, entrada, creado) VALUES (?, NOW(), FALSE, NOW())");
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $stmt = $conn->prepare("UPDATE empleados SET dentro = 0 WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $_SESSION['dentro'] = false;
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function createEmployee($username, $nombre, $password, $nif, $email) {
    global $conn;
    try {
        $stmt = $conn->stmt_init();
        $stmt->prepare("INSERT INTO empleados (username, nombre, password, NIF, email, dentro, role) VALUES (?, ?, PASSWORD(?), ?, ?, 0, 1)");
        $stmt->bind_param("sssss", $username, $nombre, $password, $nif, $email);
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        print_r($_POST);
        exit();
    }
}

function editEmployee($user_id, $username, $nombre, $nif, $email, $role) {
    global $conn;
    try {
        $stmt = $conn->stmt_init();
        $stmt->prepare("UPDATE empleados SET username = ?, nombre = ?, NIF = ?, email = ?, role = ? WHERE user_id = ?");
        $stmt->bind_param("sssssi", $username, $nombre, $nif, $email, $role, $user_id);
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function editPassword($user_id, $password1, $password2) {
    global $conn;
    if (($password1 != $password2) || (strlen($password1) < 6)) {
        return false;
    }
    try {
        $stmt = $conn->stmt_init();
        $stmt = $conn->prepare("UPDATE empleados SET password = PASSWORD(?) WHERE user_id = ?");
        $stmt->bind_param("si", $password1,  $user_id);
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['login'])) {
        if (login($_POST['username'], $_POST['password'])) {
            include "dashboard.php";
        } else {
            $mensaje = "Usuario o contraseña no válidos.";
            include "login.php";
        }
    } elseif (isset($_POST['register_entry'])) {
        if (registerEntry($_SESSION['user_id'])) {
            $mensaje = "Entrada registrada.";
        } else {
            $mensaje = "Falló el registro.";
        }
        include "dashboard.php";
    } elseif (isset($_POST['register_exit'])) {
        if (registerExit($_SESSION['user_id'])) {
            $mensaje = "Salida registrada.";
        } else {
            $mensaje = "Falló el registro.";
        }
        include "dashboard.php";
    } elseif (isset($_POST['dashboard'])) {
        include "dashboard.php";
    } elseif (isset($_POST['editame'])) {
        include "edit.php";
    } elseif (isset($_POST['crear'])) {
        include "crear.php";
    } elseif (isset($_POST['users'])) {
        include "listusers.php";
    } elseif (isset($_POST['listar'])) {
        include "listado.php";
    } elseif (isset($_POST['create_employee']) && $_SESSION['role'] == 10) {
        if (createEmployee($_POST['username'], $_POST['nombre'], $_POST['password'], $_POST['NIF'], $_POST['email'])) {
            $mensaje = "Usuario creado.";
        } else {
            $mensaje = "Fallo al crear usuario.";
        }
        include "dashboard.php";
    } elseif (isset($_POST['edit_employee'])) {
        if (editEmployee($_POST['user_id'], $_POST['username'], $_POST['nombre'], $_POST['NIF'], $_POST['email'], $_POST['role'])) {
            $mensaje = "Usuario actualizado.";
        } else {
            $mensaje = "Fallo al actualizar.";
        }
        include "dashboard.php";
    } elseif (isset($_POST['edit_password'])) {
        if (editPassword($_POST['user_id'], $_POST['password1'], $_POST['password2'])) {
            $mensaje = "Password actualizado.";
        } else {
            $mensaje = "Las contraseñas no coinciden o tienen menos de 6 caracteres.";
        }
        include "dashboard.php";
    } elseif (isset($_POST['logout'])) {
        session_destroy();
        include "login.php";
//        header("Location: index.php");
    } else {
        echo "Invalid request.<br />\n";
        print_r($_POST);
    }
} else {
    include "dashboard.php";
}
