<?php
$titulo = "Listado de usuarios";
include 'cabecera.php';

try {
    $stmt = $conn->stmt_init();
    $stmt->prepare("SELECT user_id, username, nombre FROM empleados");
    $stmt->execute();
    $stmt->bind_result($user_id, $username, $nombre);
    $stmt->store_result();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

echo "<h1>Listado de usuarios</h1>";

if ($stmt->num_rows > 0) {
    echo "<table id='customers'>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>";
    while($row = $stmt->fetch()) {
        echo "<tr>
                <td>" . $user_id. "</td>
                <td>" . $username. "</td>
                <td>" . $nombre. "</td>
                <td>
                    <form method='post'>
                        <button class='btn' name='editame' value='".$user_id."' title='Editar'><img src=img/edit.png alt='Editar' width='24'></button>
                        <button class='btn' name='listar' value='".$user_id."' title='Listar'><img src=img/lista.png alt='Listar' width='24'></button>
                    </form>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$stmt->close();
?>
    </body>
</html>