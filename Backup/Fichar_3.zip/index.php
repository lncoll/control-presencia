<?php
include_once 'global.php';

if (!isset($_SESSION['user_id']) && !isset($_POST['login'])) {
    include "login.html";
    exit();
}

function dashboard() {
    global $mensaje;
    
    if ($_SESSION['role'] == 10) {
        include "admin_dashboard.php";
    } else {
        include "dashboard.php";
    }
}

function login($username, $password) {
    global $conn;
    try {
        $stmt = $conn->prepare("SELECT * FROM empleados WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $username, $nombre, $password, $NIF, $email, $dentro, $role);
            $stmt->fetch();
            $_SESSION['user_id'] = $id;
            $_SESSION['role'] = $role;
            $_SESSION['NIF'] = $NIF;
            $_SESSION['email'] = $email;
            $_SESSION['username'] = $username;
            $_SESSION['nombre'] = $nombre;
            $_SESSION['dentro'] = $dentro;
            return true;
        }
        return false;
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function registerEntry($user_id) {
    global $conn;
    try {
        $stmt = $conn->prepare("INSERT INTO registros (user_id, reg_time, entrada, creado) VALUES (?, NOW(), TRUE, NOW())");
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $stmt = $conn->prepare("UPDATE empleados SET dentro = 1 WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $_SESSION['dentro'] = true;
            return true;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function registerExit($user_id) {
    global $conn;
    try {
        $stmt = $conn->prepare("INSERT INTO registros (user_id, reg_time, entrada, creado) VALUES (?, NOW(), FALSE, NOW())");
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $stmt = $conn->prepare("UPDATE empleados SET dentro = 0 WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $_SESSION['dentro'] = false;
            return true;
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function createEmployee($username, $nombre, $password, $nif, $email) {
    global $conn;
    try {
        $stmt = $conn->prepare("INSERT INTO empleados (username, nombre, password, NIF, email, dentro, role) VALUES (?, ?, ?, ?, ?, 0, 1)");
        $stmt->bind_param("sssss", $username, $nombre, $password, $nif, $email);
        return $stmt->execute();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        print_r($_POST);
        exit();
    }
}

function editEmployee($user_id, $username, $nombre, $password, $nif, $email, $role) {
    global $conn;
    try {
        $stmt = $conn->prepare("UPDATE empleados SET username = ?, nombre = ?, password = ?, NIF = ?, email = ?, role = ? WHERE user_id = ?");
        $stmt->bind_param("ssssssi", $username, $nombre, $password, $nif, $email, $role, $user_id);
        return $stmt->execute();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

function listaregistros() {
    global $conn;
    $result = $conn->query("SELECT e.username, a.reg_time, FROM registros a JOIN empleados e ON a.user_id = e.id");
    return $result->fetch_all(MYSQLI_ASSOC);
}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['login'])) {
        if (login($_POST['username'], $_POST['password'])) {
            dashboard();
        } else {
            echo "Invalid login credentials.";
        }
    } elseif (isset($_POST['register_entry'])) {
        if (registerEntry($_SESSION['user_id'])) {
            $mensaje = "Entry registered.";
        } else {
            $mensaje = "Failed to register entry.";
        }
        dashboard();
    } elseif (isset($_POST['register_exit'])) {
        if (registerExit($_SESSION['user_id'])) {
            $mensaje = "Exit registered.";
        } else {
            $mensaje = "Failed to register exit.";
        }
        dashboard();
    } elseif (isset($_POST['dashboard'])) {
        dashboard();
    } elseif (isset($_POST['editame'])) {
        include "edit.php";
    } elseif (isset($_POST['crear'])) {
        include "crear.php";
    } elseif (isset($_POST['create_employee']) && $_SESSION['role'] == 10) {
        if (createEmployee($_POST['username'], $_POST['nombre'], $_POST['password'], $_POST['NIF'], $_POST['email'])) {
            $mensaje = "Employee created.";
        } else {
            $mensaje = "Failed to create employee.";
        }
        dashboard();
    } elseif (isset($_POST['edit_employee'])) {
        if (editEmployee($_POST['user_id'], $_POST['username'], $_POST['nombre'], $_POST['password'], $_POST['NIF'], $_POST['email'], $_POST['role'])) {
            $mensaje = "Employee edited.";
        } else {
            $mensaje = "Failed to edit employee.";
        }
        dashboard();
    } elseif (isset($_POST['logout'])) {
        session_destroy();
        include "login.html";
//        header("Location: index.php");
    } else {
        echo "Invalid request.<br />\n";
        print_r($_POST);
    }
} else {
    include "login.html";
}
?>