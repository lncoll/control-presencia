<?php
$titulo = "Listado de usuarios";
include 'cabecera.php';

if ($_POST['listar'] != "") $busca_user = $_POST['listar']; else $busca_user = $_SESSION['user_id'];
if ($_POST['inicio'] != "") $inicio = $_POST['inicio']; else $inicio = date('Y-m-01');
if ($_POST['fin'] != "") $fin = $_POST['fin']." 23:59:59"; else $fin = date('Y-m-t')." 23:59:59";

$stmt = $conn->stmt_init();
$stmt->prepare("SELECT nombre FROM empleados WHERE user_id = ?;");
try {
    $stmt->bind_param("i", $busca_user);
    $stmt->execute();
    $stmt->bind_result($nombre);
    $stmt->store_result();
    $stmt->fetch();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

$stmt->prepare("SELECT reg_time, entrada FROM registros WHERE reg_time BETWEEN ? AND ? AND user_id = ? ORDER BY reg_id ASC;");
try {
    $stmt->bind_param("ssi", $inicio, $fin, $busca_user);
    $stmt->execute();
    $stmt->bind_result($reg_time, $entrada);
    $stmt->store_result();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>
        <form method="post" class="busca-form">
            <label for="inicio">Inicio</label>
            <input type="date" name="inicio" value="<?= $inicio ?>" required>
            <label for="fin">Fin</label>
            <input type="date" name="fin" value="<?= substr($fin, 0, 10) ?>" required>
            <button type="submit" name="listar" value="<?= $busca_user ?>">Filtrar</button>
        </form>
        <table id="tlistado">
            <caption>Registros para: <?= $nombre ?></caption>
            <tr><th>Fecha:</th><th>Entrada:</th><th>Salida:</th><th>Tiempo:</th></tr>
<?php
            if ($stmt->num_rows > 0) {
                while($row = $stmt->fetch()) {
                    if ($entrada) {
                        $ent = new DateTime($reg_time);
                        $fecha = $ent->format('d/m/Y');
                        if ($sal) {
                            $lapso = $ent->diff($sal);
                            echo "<tr><td>" . $fecha . "</td><td>" . $ent->format('H:i') . "</td><td>" . $sal->format('H:i') . "</td><td>" . $lapso->format('%H:%I') . "</td></tr>\n";
                        } else
                            echo "<tr><td>" . $fecha . "</td><td>" . $ent->format('H:i') . "</td><td>---</td><td>---</td></tr>\n";                        
                    } else {
                        $sal = new DateTime($reg_time);
                    }
                }
            } else {
                echo "<tr><td colspan='4'>No hay registros</td></tr>";
            }
            $stmt->close();

/*
require 'vendor/autoload.php';
use Dompdf\Dompdf;

if (isset($_POST['generate_pdf'])) {
    $dompdf = new Dompdf();
    $html = "<h1>Listado de usuarios</h1>";

    if ($stmt->num_rows > 0) {
        $html .= "<table id='tlistado'>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Nombre</th>
                    </tr>";
        $stmt->data_seek(0); // Reset pointer to the beginning
        while($stmt->fetch()) {
            $html .= "<tr>
                        <td>" . $user_id. "</td>
                        <td>" . $username. "</td>
                        <td>" . $nombre. "</td>
                      </tr>";
        }
        $html .= "</table>";    
    } else {
        $html .= "0 results";
    }

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->render();
    $dompdf->stream("listado_usuarios.pdf", array("Attachment" => 0));
    exit();
}
?>

<form method="post">
    <button type="submit" name="generate_pdf">Generar PDF</button>
</form>
*/

            ?>
        </table>
    </body>
</html>