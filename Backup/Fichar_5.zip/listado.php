<?php
$titulo = "Listado de usuarios";
include 'cabecera.php';


?>
    </body>
</html>