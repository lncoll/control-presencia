<?php
include 'global.php';

if ($_SESSION['dentro']) { $cuantos = 31; } else { $cuantos = 32; };
$result = $conn->prepare("SELECT * FROM registros WHERE user_id = ? ORDER BY reg_id DESC LIMIT ?;");
try {
    $result->bind_param("ii", $_SESSION['user_id'], $cuantos);
    $result->execute();
    $result->store_result();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

$titulo = "Dashboard";
include 'cabecera.php';
//if (isset($mensaje)) echo "<h2 id='mensaje'>" . $mensaje . "</h2>";

echo "        <h1>Bienvenid@ " . $_SESSION['username'] . " </h1>\n";
echo "        <form method='post' class='reg-form'>\n";
if ($_SESSION['dentro']) {
    echo "            <button type = submit name = register_exit>Salida</button>\n";
} else {
    echo "            <button type = submit name = register_entry>Entrada</button>\n";
}
echo "        </form>\n";
?>
        <table id="customers">
            <caption>Ultimos registros</caption>
            <tr><th>Fecha:</th><th>Entrada:</th><th>Salida:</th><th>Tiempo:</th></tr>
<?php
            if ($result->num_rows > 0) {
                $result->bind_result($reg_id, $user_id, $reg_time, $entrada, $creado, $modificado, $spare);
                while($row = $result->fetch()) {
                    if ($entrada) {
                        $ent = new DateTime($reg_time);
                        $fecha = $ent->format('d/m/Y');
                        if ($sal) {
                            $lapso = $ent->diff($sal);
                            echo "<tr><td>" . $fecha . "</td><td>" . $ent->format('H:i') . "</td><td>" . $sal->format('H:i') . "</td><td>" . $lapso->format('%H:%I') . "</td></tr>\n";
                        } else
                            echo "<tr><td>" . $fecha . "</td><td>" . $ent->format('H:i') . "</td><td>---</td><td>---</td></tr>\n";                        
                    } else {
                        $sal = new DateTime($reg_time);
                    }
                }
            } else {
                echo "<tr><td colspan='4'>No hay registros</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </body>
</html>