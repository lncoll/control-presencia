<?php
$titulo = "Listado de usuarios";
include 'cabecera.php';

$sql = "SELECT user_id, username, nombre FROM empleados";
$result = $conn->query($sql);

echo "<h1>Listado de usuarios</h1>";

if ($result->num_rows > 0) {
    echo "<table id='customers'>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["user_id"]. "</td>
                <td>" . $row["username"]. "</td>
                <td>" . $row["nombre"]. "</td>
                <td>
                    <form method='post'>
                        <button class='btn' name='editame' value='".$row["user_id"]."' title='Editar'><img src=img/edit.png alt='Editar' width='24'></button>
                        <button class='btn' name='listar' value='".$row["user_id"]."' title='Listar'><img src=img/lista.png alt='Listar' width='24'></button>
                    </form>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
//                 <td><a href='edituser.php?id=" . $row["user_id"] . "'>Editar</a></td>
$conn->close();
?>
    </body>
</html>