<?php
include_once 'global.php';

// Fetch the last 15 registers
$result = $conn->prepare("SELECT * FROM registros WHERE user_id = ? ORDER BY reg_id DESC LIMIT 30;");
try {
    $result->bind_param("i", $_SESSION['user_id']);
    $result->execute();
    $result->store_result();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="estilo.css" rel="stylesheet" type="text/css">
        <title>User Dashboard</title>
    </head>
    <body>
        <div class = "navbar">
            <form method="post">
                <button type = submit name = crear>Crear usuario</button>
                <button type = submit name = edita>Editar usuario</button>
                <button type = submit name = editame>Mis datos</button>
                <button type = submit name = logout>Salir</button>
            </form>
        </div>
        <h1>Bienvenido <?php echo $_SESSION['username']; ?> </h1>
        <form method="post" class="reg-form">
        <?php
        if ($_SESSION['dentro']) {
            echo "<button type = submit name = register_exit>Salida</button>";
        } else {
            echo "<button type = submit name = register_entry>Entrada</button>";
        }
        ?>
        </form>
        <table border="1">
            <caption>Ultimos registros</caption>
            <tr>
                <th>-</th>
                <th>ID</th>
                <th>Fecha</th>
                <th>Hora</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                $result->bind_result($reg_id, $user_id, $reg_time, $entrada, $creado, $modificado, $spare);
                while($row = $result->fetch()) {
//                    $result->bind_result($reg_id, $user_id, $reg_time, $entrada, $creado, $modificado, $spare);
                    if ($entrada) {
                        $entrada = "Entrada";
                    } else {
                        $entrada = "Salida";
                    }
                    $tiempo = preg_split('/\s+/', $reg_time);
                    echo "<!-- -->            <tr>";
                    echo "<td>" . $entrada . "</td>";
                    echo "<td>" . $reg_id . "</td>";
                    echo "<td>" . $tiempo[0] . "</td>";
                    echo "<td>" . $tiempo[1] . "</td>";
                    echo "</tr>\n";
                }
            } else {
                echo "<tr><td colspan='3'>No records found</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </body>
</html>